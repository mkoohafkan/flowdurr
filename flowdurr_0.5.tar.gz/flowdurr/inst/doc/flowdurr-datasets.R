## ----setup, include=FALSE------------------------------------------------
require(knitr)
opts_chunk$set(error=FALSE, tidy=TRUE, dpi=100)
require(flowdurr)

## ----eval=c(2:4)---------------------------------------------------------
esptraces = get_forecast()
data(esptraces)
names(esptraces)
head(esptraces[1:6])

## ----eval=c(2:4)---------------------------------------------------------
usgstraces = get_waterdata()
data(usgstraces)
names(usgstraces)
head(usgstraces)

## ----eval=c(2:4)---------------------------------------------------------
hspftraces = get_hspf("path/to/file.csv")
data(hspftraces)
names(hspftraces)
head(hspftraces)

## ----echo=c(2:4), eval=c(1,3:4)------------------------------------------
rm(list=ls())
demo(workedexample)
data(workedexample)
ls()

