## ----setup, include=FALSE------------------------------------------------
require(knitr)
opts_chunk$set(error=FALSE, tidy=TRUE, dpi=100, results='markup', warning=FALSE, message=FALSE)

## ----import-data---------------------------------------------------------
require(flowdurr)
data(hspftraces)
# reformat to water year
hspf.wyear = split_by_wateryear(hspftraces)
hspf.clean = clean_flowdata(hspf.wyear, -1, NA)
hspf.clean = clean_flowdata(hspf.clean, 0, 1e-5)
hspf.clean = strip_na_cols(hspf.clean)

## ----make-plots, fig.show='hold', echo=c(1:2)----------------------------
spaghetti = plot_all_traces(hspf.clean)
box = plot_boxcounts(hspf.clean, flowdurations=c(1,3))
spaghetti
box

## ----spaghetti-mod, echo=c(1:11)-----------------------------------------
# modify text size and grid lines
require(ggplot2)
mod.textsize = theme(text=element_text(size=20), axis.text.x=element_text(size=rel(1))) 
mod.yticks = scale_y_continuous('Daily flow (cfs)', minor_breaks=seq(0,600,10), breaks=seq(0,600,100))
spaghettimod = spaghetti + mod.textsize + mod.yticks
# also modify the legend to indicate the timespan and total number of traces.
traces = as.numeric(substr(names(hspf.clean)[3:ncol(hspf.clean)], 3, 6))
tlbl = paste(min(traces), '-', max(traces), ' (', length(traces), ' traces)', sep='')
mod.legend = scale_color_manual('', labels=c(tlbl, 'mean', 'median'), 
                                values=c('black', 'red', 'blue'))
spaghettimod = spaghettimod + mod.legend + theme(legend.position='top')
spaghettimod

## ----save-plot, eval=FALSE-----------------------------------------------
#  ggsave('spaghettiplot.pdf', plot=spaghettimod, width=9, height=6.5)

## ----box-mod1, tidy=FALSE, echo=1:8--------------------------------------
mod.yticks = scale_y_continuous('annual maximum 1-day, 3-day flow (cfs)',
               limits=c(1, 600), breaks = c(1, 5, 10, 50, 100, 500),
               minor_breaks=c(seq(0.01,0.09,0.01), seq(0.1,0.9,0.1), 
			   seq(1,9,1), seq(10,90,10), seq(100,600,100))) 
mod.legend = scale_fill_brewer('', palette='Set1', 
               labels=c("max 1-day flow", "max 3-day flow"))
boxmod = box + mod.yticks + mod.legend + mod.textsize + 
         theme(legend.position='top') + coord_trans(y="log10")
boxmod

## ----restructure-plot----------------------------------------------------
# check out the structure of a ggplot
names(boxmod)
boxmod$mapping
boxmod$layers
# you can replace layers directly
class(boxmod$layers)
# change to a jitter plot
boxmod$layers[[1]] = NULL
boxmod + geom_jitter(pch=21)
# but changing aesthetics can reset the legend and color scale
boxmod$mapping[[3]] = NULL
boxmod + geom_jitter(aes(color=flow.duration))

## ----remake-plot---------------------------------------------------------
plotdata = box$data
# note the plot data structure is not the same as the input data
identical(plotdata, hspf.clean)
summary(plotdata)
ggplot(plotdata, aes(x=max.flow, fill=flow.duration)) + geom_histogram(position ="dodge") + facet_wrap(~month, scale="free")

